import tkinter as tk
  

# Create the window.
window = tk.Tk()
window.title("BIOS Menu")
window.geometry("600x400")

# Create the labels.
label_1 = tk.Label(text="Ultra 64 BIOS System")
label_2 = tk.Label(text="1. Boot from CD/DVD")
label_3 = tk.Label(text="2. Boot from Hard Disk")
label_4 = tk.Label(text="3. Enter Setup")
label_5 = tk.Label(text="4. Exit")

# Create the buttons.
button_1 = tk.Button(text="Boot from CD/DVD", command=lambda: print("Booting from CD/DVD"))
button_2 = tk.Button(text="Boot from Hard Disk", command=lambda: print("Booting from Hard Disk"))
button_3 = tk.Button(text="Enter Setup", command=lambda: print("Entering Setup"))
button_4 = tk.Button(text="Exit", command=window.quit)

 
 ## @ Flames lLC 20XX [C] - TEAM FLAMES AI - 2023

# Create the three squares.
square_1 = tk.Canvas(width=100, height=100, bg="red")
square_2 = tk.Canvas(width=100, height=100, bg="green")
square_3 = tk.Canvas(width=100, height=100, bg="blue")

# Add text to the squares.
square_1.create_text(50, 50, text="Super Mario 64")
square_2.create_text(50, 50, text="Ocarina of Time")
square_3.create_text(50, 50, text="Majora's Mask")

# Place the squares on the window.
square_1.place(x=100, y=100)
square_2.place(x=200, y=100)
square_3.place(x=300, y=100)

# Place the labels and buttons on the window.
label_1.pack()
label_2.pack()
label_3.pack()
label_4.pack()
label_5.pack()
button_1.pack()
button_2.pack()
button_3.pack()
button_4.pack()

# Start the event loop.
window.mainloop()
