import math
## @Flames LLC 20XX [C] 5.14.20XX
def main():
    while True:
        print("What would you like to do? (add, subtract, multiply, divide, sin, cos, tan, sqrt, ln, exp)")
        operation = input()

        if operation == "add":
            print("Enter two numbers to add:")
            number1 = float(input())
            number2 = float(input())
            print("The sum is", number1 + number2)

        elif operation == "subtract":
            print("Enter two numbers to subtract:")
            number1 = float(input())
            number2 = float(input())
            print("The difference is", number1 - number2)

        elif operation == "multiply":
            print("Enter two numbers to multiply:")
            number1 = float(input())
            number2 = float(input())
            print("The product is", number1 * number2)

        elif operation == "divide":
            print("Enter two numbers to divide:")
            number1 = float(input())
            number2 = float(input())
            print("The quotient is", number1 / number2)

        elif operation == "sin":
            print("Enter an angle in degrees to find the sine:")
            angle = float(input())
            print("The sine of", angle, "is", math.sin(angle))

        elif operation == "cos":
            print("Enter an angle in degrees to find the cosine:")
            angle = float(input())
            print("The cosine of", angle, "is", math.cos(angle))

        elif operation == "tan":
            print("Enter an angle in degrees to find the tangent:")
            angle = float(input())
            print("The tangent of", angle, "is", math.tan(angle))

        elif operation == "sqrt":
            print("Enter a number to find its square root:")
            number = float(input())
            print("The square root of", number, "is", math.sqrt(number))

        elif operation == "ln":
            print("Enter a number to find its natural logarithm:")
            number = float(input())
            print("The natural logarithm of", number, "is", math.log(number))

        elif operation == "exp":
            print("Enter a number to find its exponential:")
            number = float(input())
            print("The exponential of", number, "is", math.exp(number))

        else:
            print("Invalid operation.")

if __name__ == "__main__":
    main()
